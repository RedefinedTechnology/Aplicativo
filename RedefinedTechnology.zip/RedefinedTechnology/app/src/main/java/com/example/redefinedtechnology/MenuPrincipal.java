package com.example.redefinedtechnology;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;


public class MenuPrincipal extends AppCompatActivity {

    TextView txNome;
    Button btRedes;
    Button btServidor;
    Button btCloud;
    Button btInternet;
    Button btSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        txNome = findViewById(R.id.textViewNome);
        btRedes = findViewById(R.id.buttonRedes);
        btServidor = findViewById(R.id.buttonServidor);
        btCloud = findViewById(R.id.buttonCloud);
        btInternet = findViewById(R.id.buttonInternet);
        btSair = findViewById(R.id.buttonSair);

        //chamando o nome do usuário na tela
        Intent intent = getIntent();
        Intent MenuPrincipal = getIntent();
        Bundle bdnome = intent.getExtras();
        txNome.setText(bdnome.getString("usuario"));

        btRedes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AbrirCloud();
            }
        });
        btServidor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AbrirServidor();
            }
        });
        btInternet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AbrirInternet();
            }
        });
        btCloud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AbrirCloud();
            }
        });
        btSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });
    }

    public void AbrirCloud(){
        Intent intent = new Intent(MenuPrincipal.this, Cloud.class);
        startActivity(intent);
    }
    public void AbrirServidor(){
        Intent intent = new Intent(MenuPrincipal.this, Servidor.class);
        startActivity(intent);
    }
    public void AbrirInternet(){
        Intent intent = new Intent(MenuPrincipal.this, Internet.class);
        startActivity(intent);
    }
    public void AbrirRedes(){
        Intent intent = new Intent(MenuPrincipal.this, Redes.class);
        startActivity(intent);
    }
}