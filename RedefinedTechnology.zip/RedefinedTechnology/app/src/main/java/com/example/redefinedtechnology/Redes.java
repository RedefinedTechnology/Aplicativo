package com.example.redefinedtechnology;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Redes extends AppCompatActivity
{

    Button btEnviar;
    Button btVoltar;
    EditText editTextSolicitacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redes);



        editTextSolicitacao = (EditText) findViewById(R.id.editTextSolicitacao);
        btEnviar = (Button) findViewById(R.id.buttonSolicitar);
        btVoltar = (Button) findViewById(R.id.buttonSair);

        editTextSolicitacao.requestFocus();

        Intent itCadastro = getIntent();

        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // fecha a Intent atual
            }
        });

        btEnviar.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            String texto = editTextSolicitacao.getText().toString();

                                            if (!texto.equals("")) {
                                                Toast.makeText(Redes.this, "SUCESSO! Solicitação enviada, aguarde contato de nossa equipe em seu e-mail.", Toast.LENGTH_LONG).show();
                                            } else {
                                                Toast.makeText(Redes.this, "ATENÇÃO! Preencha o campo acima antes de solicitar o serviço.", Toast.LENGTH_LONG).show();
                                            }
                                            LimpaDados();
                                        }
                                    }
        );
    };
    protected void LimpaDados() {
        editTextSolicitacao.getText().clear();
    }


    public void MenuPrincipal(){
        Intent MenuPrincipal = new Intent(Redes.this
                , MenuPrincipal.class);
        startActivity(MenuPrincipal);
    }
}