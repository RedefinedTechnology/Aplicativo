package com.example.redefinedtechnology;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import com.santalu.maskedittext.MaskEditText;

public class Cadastro extends AppCompatActivity {

    EditText nome;
    MaskEditText celular;
    MaskEditText CPF;
    EditText email;
    EditText senha;
    EditText confirmar;
    Button btCadastro;
    Button btVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actitity_cadastro);
        nome = findViewById(R.id.editTextNome);
        celular = findViewById(R.id.editTextCelular);
        CPF = findViewById(R.id.editTextCPF);
        email = findViewById(R.id.editTextEmail);
        senha = findViewById(R.id.editTextSenha);
        confirmar = findViewById(R.id.editTextConfirmar);
        btCadastro = findViewById(R.id.buttonCadastro);
        btVoltar = findViewById(R.id.buttonSair);

        Intent itCadastro = getIntent();

        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // fecha a Intent atual
            }
        });

        btCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                nome.getText().toString(); email.getText().toString();
                senha.getText().toString(); confirmar.getText().toString();
                CPF.getText().toString(); celular.getText().toString();

                String txnome = nome.getText().toString();
                String txemail = email.getText().toString();
                String txsenha = senha.getText().toString();
                String txconfirmar = confirmar.getText().toString();
                String txCPF = CPF.getText().toString();
                String txcelular = celular.getText().toString();

                if(txnome.isEmpty() || txemail.isEmpty() || txsenha.isEmpty() || txconfirmar.isEmpty() ||
                        txCPF.isEmpty() || txcelular.isEmpty())
                {
                    Toast.makeText(Cadastro.this,"ATENÇÃO! Preencha corretamente os campos",Toast.LENGTH_LONG).show();
                }
                else if(txsenha.equals(txconfirmar) == false){
                    Toast.makeText(Cadastro.this,"ATENÇÃO! As senhas não conferem, refaça a operação para prosseguir.",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(Cadastro.this,"SUCESSO! Cadastrado com sucesso!",Toast.LENGTH_LONG).show();
                    VoltarLogin();
                }

            }
        });
    };
    public void LimparDados(){
        nome.getText().clear();
        email.getText().clear();
        senha.getText().clear();
        CPF.getText().clear();
        confirmar.getText().clear();
        celular.getText().clear();
    }

    public void VoltarLogin(){
        Intent VoltarLogin = new Intent(Cadastro.this
                , MainActivity.class);
        startActivity(VoltarLogin);
    }
}

