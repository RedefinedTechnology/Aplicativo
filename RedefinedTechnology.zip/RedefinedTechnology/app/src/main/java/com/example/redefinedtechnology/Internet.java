package com.example.redefinedtechnology;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.redefinedtechnology.R;

public class Internet extends AppCompatActivity {
    Button btEnviar;
    EditText editTextSolicitacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internet);
        editTextSolicitacao = (EditText) findViewById(R.id.editTextSolicitacao);
        btEnviar = (Button) findViewById(R.id.buttonSolicitar);

        editTextSolicitacao.requestFocus();
        btEnviar.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            String texto = editTextSolicitacao.getText().toString();

                                            if (!texto.equals("")) {
                                                Toast.makeText(Internet.this, "SUCESSO! Solicitação enviada, aguarde contato de nossa equipe em seu e-mail.", Toast.LENGTH_LONG).show();
                                            } else {
                                                Toast.makeText(Internet.this, "ATENÇÃO! Preencha o campo acima antes de solicitar o serviço.", Toast.LENGTH_LONG).show();
                                            }
                                            LimpaDados();
                                        }
                                    }
        );
    };

    protected void LimpaDados() {
        editTextSolicitacao.getText().clear();
    }
}