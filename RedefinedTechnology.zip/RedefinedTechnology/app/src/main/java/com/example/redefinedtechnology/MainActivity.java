package com.example.redefinedtechnology;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
         EditText txtUsuario;
         EditText txtSenha;
         Button btnLogin;
         Button btnCadastro;
        @Override
        protected void onCreate(Bundle savedInstanceState)
        {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            txtUsuario = (EditText) findViewById(R.id.txtUsuario);
            txtSenha = (EditText) findViewById(R.id.txtSenha);
            btnLogin = (Button) findViewById(R.id.btnLogin);
            btnCadastro = (Button) findViewById(R.id.btnCadastro);
            txtUsuario.requestFocus();

            btnLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String usuario = txtUsuario.getText().toString();
                    String senha = txtSenha.getText().toString();

                    if(!usuario.equals("") && !senha.equals("")){
                       if (usuario.equals("admin") && senha.equals("1234")){
                           Toast.makeText(MainActivity.this, "Login efetuado com sucesso!",Toast.LENGTH_LONG).show();
                           EntrarSistema();
                           LimparCampos();
                           txtUsuario.requestFocus();
                           Intent intent = new Intent(MainActivity.this, MenuPrincipal.class);
                           Bundle bdnome = new Bundle();
                           bdnome.putString("usuario", usuario);
                           intent.putExtras(bdnome);
                           startActivity(intent);
                       }
                       else{
                           Toast.makeText(MainActivity.this, "Usuário não encontrado!",Toast.LENGTH_LONG).show();
                       }
                    }else if(usuario.isEmpty())
                    {
                        txtUsuario.requestFocus();
                        Toast.makeText(MainActivity.this, "ATENÇÃO! Preencha o campo Usuário.", Toast.LENGTH_LONG).show();
                    }
                    else if (senha.isEmpty())
                    {
                        txtSenha.requestFocus();
                        Toast.makeText(MainActivity.this, "ATENÇÃO! Preencha o campo Senha.", Toast.LENGTH_LONG).show();
                    }
                    else{
                        Toast.makeText(MainActivity.this,"ERRO! Preencha corretamente os campos",Toast.LENGTH_LONG).show();
                    }
                    }
                });

            btnCadastro.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                AbrirCadastro();
                LimparCampos();
                }
            });
        }

        public void AbrirCadastro(){
        Intent intent = new Intent(MainActivity.this
                , Cadastro.class);
        startActivity(intent);
        }

        public void EntrarSistema(){
        Intent itEntrar = new Intent(MainActivity.this, MenuPrincipal.class);
        startActivity(itEntrar);
        }

        public void LimparCampos(){
            txtUsuario.getText().clear();
            txtSenha.getText().clear();
        }


}
